# خير | Khair — brand notes

## Logo files

- khair-logo.svg — primary bilingual horizontal logo. Transparent background; suitable for the website header, documents, and print.
- khair-mark.svg — icon-only vector for the website favicon, app icon, and social avatar.
- khair-logo.png — high-resolution preview on white.
- khair-mark.png — icon preview on white.

## Colors

- Deep green: #174B37 — primary wordmark and circular food-rescue loop.
- Natural green: #6D9E64 — leaf and English wordmark.
- Soft sage: #A8C48E — inner plate ring.
- Warm coral: #E88361 — heart accent.
- White: #FFFFFF — plate and optional background.

The SVG files can be uploaded to Canva as vector artwork. The primary logo contains the Arabic name «خير» and the smaller English name “Khair”; the icon file is intentionally text-free for small uses.
