/* خير — نموذج أولي يعمل داخل المتصفح، ويحفظ بياناته في localStorage. */
(function () {
  "use strict";

  const STORE_KEY = "khair-platform-v1";
  const fmt = new Intl.NumberFormat("ar-DZ");
  const dateFmt = new Intl.DateTimeFormat("ar-DZ", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
  const categoryMeta = {
    "وجبات جاهزة": { css: "meals", icon: "♨", glyph: "✿" },
    "مخبوزات": { css: "bakery", icon: "♧", glyph: "◕" },
    "خضار وفواكه": { css: "produce", icon: "❋", glyph: "✿" },
    "مواد غذائية": { css: "grocery", icon: "▤", glyph: "▣" },
    "حلويات": { css: "dessert", icon: "✿", glyph: "❀" }
  };
  const seedData = function () {
    const now = Date.now();
    const plus = (hours) => new Date(now + hours * 3600000).toISOString();
    const ago = (hours) => new Date(now - hours * 3600000).toISOString();
    return {
      profile: null,
      offers: [
        { id: "seed-1", donor: "مخبز الحي", donorType: "donor", city: "الجزائر", address: "حيدرة، الجزائر", phone: "0550 123 456", title: "خبز طازج ومخبوزات اليوم", category: "مخبوزات", quantity: 32, unit: "كيس", readyAt: plus(.3), deadline: plus(3), storage: "يحفظ في مكان جاف ونظيف", allergens: "يحتوي على القمح والغلوتين", description: "دفعة طازجة من الخبز التقليدي والكرواسون، مغلفة وجاهزة للاستلام من المخبز.", createdAt: ago(1.5), requests: [], status: "active", flagged: false },
        { id: "seed-2", donor: "مطعم دار الليمون", donorType: "donor", city: "وهران", address: "شارع العربي بن مهيدي، وهران", phone: "0551 234 567", title: "وجبات كسكس بالخضار", category: "وجبات جاهزة", quantity: 24, unit: "وجبة", readyAt: plus(.5), deadline: plus(4), storage: "تحفظ مبردة عند 4°م", allergens: "قد يحتوي على الغلوتين", description: "وجبات كسكس بالخضار محضرة اليوم. تُسلّم في عبوات غذائية محكمة الإغلاق.", createdAt: ago(2), requests: [], status: "active", flagged: false },
        { id: "seed-3", donor: "سوق الواحة", donorType: "donor", city: "قسنطينة", address: "حي المنصورة، قسنطينة", phone: "0552 345 678", title: "صناديق خضار وفواكه طازجة", category: "خضار وفواكه", quantity: 8, unit: "صندوق", readyAt: plus(.2), deadline: plus(5), storage: "مكان بارد وجيد التهوية", allergens: "لا توجد معلومات حساسية", description: "خضار وفاكهة موسمية بحالة جيدة، مناسبة للاستهلاك المباشر والتوزيع.", createdAt: ago(3), requests: [], status: "active", flagged: false },
        { id: "seed-4", donor: "حلويات نسمات", donorType: "donor", city: "الجزائر", address: "باب الزوار، الجزائر", phone: "0553 456 789", title: "قطع كيك وحلويات مشكلة", category: "حلويات", quantity: 40, unit: "قطعة", readyAt: plus(1), deadline: plus(6), storage: "تحفظ مبردة", allergens: "تحتوي على الحليب والبيض والغلوتين", description: "حلويات متنوعة من تحضير اليوم، محفوظة في علب محكمة.", createdAt: ago(.5), requests: [], status: "active", flagged: false },
        { id: "seed-5", donor: "متجر سنابل", donorType: "donor", city: "سطيف", address: "وسط المدينة، سطيف", phone: "0554 567 890", title: "مواد غذائية معبأة", category: "مواد غذائية", quantity: 15, unit: "سلة", readyAt: plus(1.2), deadline: plus(7), storage: "يحفظ في مكان جاف", allergens: "يرجى مراجعة ملصق كل منتج", description: "سلال تحتوي على مواد جافة مغلقة وسليمة، تاريخ صلاحيتها موضح على العبوات.", createdAt: ago(4), requests: [], status: "active", flagged: false }
      ],
      history: [
        { id: "history-1", title: "وجبات دجاج وأرز", donor: "مطعم المائدة", charity: "جمعية بسمة أمل", city: "الجزائر", quantity: 35, unit: "وجبة", date: ago(28), distributed: true },
        { id: "history-2", title: "خضار وفاكهة موسمية", donor: "سوق النخيل", charity: "جمعية يد العون", city: "البليدة", quantity: 12, unit: "صندوق", date: ago(52), distributed: true },
        { id: "history-3", title: "مخبوزات متنوعة", donor: "فرن الصباح", charity: "جمعية الرحمة", city: "وهران", quantity: 48, unit: "كيس", date: ago(75), distributed: true }
      ],
      accounts: [
        { name: "مخبز الحي", role: "donor", city: "الجزائر" },
        { name: "جمعية بسمة أمل", role: "charity", city: "الجزائر" },
        { name: "سوق الواحة", role: "donor", city: "قسنطينة" },
        { name: "جمعية يد العون", role: "charity", city: "البليدة" }
      ],
      reports: []
    };
  };

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORE_KEY));
      if (saved && Array.isArray(saved.offers)) return Object.assign(seedData(), saved);
    } catch (error) {
      console.warn("تعذر قراءة بيانات خير المحفوظة.", error);
    }
    return seedData();
  }
  let state = loadState();
  let currentView = "home";
  let dashboardTab = "offers";
  let selectedRole = "donor";
  let detailOfferId = null;
  let toastTimer = null;

  const byId = (id) => document.getElementById(id);
  const esc = (value) => String(value == null ? "" : value).replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  const save = () => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }
    catch (error) { toast("تعذر حفظ التغييرات في هذا المتصفح.", "error"); }
  };
  const uid = () => "k-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
  const localInputValue = (date) => {
    const d = date ? new Date(date) : new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  };
  const niceDate = (value) => {
    if (!value) return "—";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "—" : dateFmt.format(date);
  };
  const remainingQty = (offer) => {
    const held = (offer.requests || []).filter((r) => ["pending", "accepted", "handed_over", "received"].includes(r.status)).reduce((sum, r) => sum + Number(r.quantity || 0), 0);
    return Math.max(0, Number(offer.quantity || 0) - held);
  };
  const acceptedRequests = (offer) => (offer.requests || []).filter((r) => ["accepted", "handed_over", "received"].includes(r.status));
  const isActive = (offer) => offer.status !== "completed" && offer.status !== "hidden" && new Date(offer.deadline).getTime() > Date.now() && remainingQty(offer) > 0;
  const activeOffers = () => state.offers.filter(isActive);
  const roleName = (role) => role === "donor" ? "مطعم أو متجر" : "جمعية خيرية";
  const statusText = (status) => ({ pending: "بانتظار الموافقة", accepted: "تم قبول الطلب", handed_over: "بانتظار تأكيد الاستلام", received: "تم الاستلام", rejected: "مرفوض", distributed: "تم التوزيع" }[status] || status);
  const requestStatusClass = (status) => status === "pending" ? "pending" : ["accepted", "handed_over"].includes(status) ? "reserved" : ["received", "distributed"].includes(status) ? "complete" : "expired";
  const cat = (category) => categoryMeta[category] || categoryMeta["مواد غذائية"];
  const toast = (message, type) => {
    const box = byId("toastRegion");
    const item = document.createElement("div");
    item.className = "toast" + (type ? " " + type : "");
    item.textContent = message;
    box.appendChild(item);
    window.setTimeout(() => item.remove(), 3600);
  };

  function showView(view) {
    if (view === "dashboard" && !state.profile) {
      openRoleModal("أنشئ حسابك لتتابع طلباتك وعروضك.");
      return;
    }
    currentView = view;
    document.querySelectorAll(".view").forEach((node) => node.classList.toggle("active", node.id === "view-" + view));
    document.querySelectorAll(".nav-link[data-view]").forEach((node) => node.classList.toggle("active", node.dataset.view === view));
    byId("mainNav").classList.remove("open");
    window.scrollTo({ top: 0, behavior: "smooth" });
    render();
  }

  function offerCard(offer) {
    const meta = cat(offer.category);
    const deadlineHours = (new Date(offer.deadline).getTime() - Date.now()) / 3600000;
    const badge = deadlineHours <= 2 ? '<span class="offer-badge urgent">ينتهي قريبًا</span>' : '<span class="offer-badge">متاح للاستلام</span>';
    return '<article class="offer-card"><div class="offer-image ' + meta.css + '"><span class="offer-image-deco">✳</span><span class="offer-food">' + meta.glyph + '</span>' + badge + '</div><div class="offer-body"><div class="offer-org"><span class="org-dot">' + esc((offer.donor || "خ").slice(0, 1)) + '</span>' + esc(offer.donor) + '</div><h3>' + esc(offer.title) + '</h3><div class="offer-location"><span>⌖</span>' + esc(offer.city) + ' · ' + esc(offer.category) + '</div><div class="offer-meta"><span class="offer-meta-item">♧ <strong>' + fmt.format(remainingQty(offer)) + ' ' + esc(offer.unit) + '</strong></span><span class="offer-meta-item">◷ <strong>' + esc(niceDate(offer.readyAt)) + '</strong></span></div><div class="offer-footer"><span class="deadline ' + (deadlineHours <= 2 ? "soon" : "") + '">آخر استلام: ' + esc(niceDate(offer.deadline)) + '</span><button class="card-link" data-action="details" data-id="' + esc(offer.id) + '">التفاصيل ←</button></div></div></article>';
  }

  function renderHome() {
    const list = activeOffers().slice(0, 3);
    byId("homeOffers").innerHTML = list.length ? list.map(offerCard).join("") : '<div class="dashboard-empty" style="grid-column:1/-1">لا توجد عروض نشطة حاليًا. عد قريبًا لمشاهدة الجديد.</div>';
    byId("navCount").textContent = fmt.format(activeOffers().length);
    const completed = state.history.length + state.offers.flatMap((o) => (o.requests || []).filter((r) => ["received", "distributed"].includes(r.status))).length;
    byId("heroMeals").textContent = fmt.format(completed);
    byId("footerYear").textContent = new Date().getFullYear();
  }

  function renderOffers() {
    const cities = Array.from(new Set(state.offers.filter(isActive).map((offer) => offer.city).filter(Boolean))).sort((a, b) => a.localeCompare(b, "ar"));
    const citySelect = byId("cityFilter");
    const oldCity = citySelect.value;
    citySelect.innerHTML = '<option value="">كل المدن</option>' + cities.map((city) => '<option value="' + esc(city) + '">' + esc(city) + "</option>").join("");
    if (cities.includes(oldCity)) citySelect.value = oldCity;

    const query = byId("searchInput").value.trim().toLocaleLowerCase("ar");
    const city = citySelect.value;
    const category = byId("categoryFilter").value;
    const sort = byId("sortFilter").value;
    let list = activeOffers().filter((offer) => {
      const haystack = [offer.title, offer.donor, offer.city, offer.category].join(" ").toLocaleLowerCase("ar");
      return (!query || haystack.includes(query)) && (!city || offer.city === city) && (!category || offer.category === category);
    });
    if (sort === "newest") list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    else if (sort === "quantity") list.sort((a, b) => remainingQty(b) - remainingQty(a));
    else list.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
    byId("offersGrid").innerHTML = list.map(offerCard).join("");
    byId("offersEmpty").classList.toggle("hidden", list.length > 0);
    byId("offersGrid").classList.toggle("hidden", list.length === 0);
    byId("offersTotal").textContent = fmt.format(activeOffers().length);
    byId("resultsLabel").textContent = list.length ? "يعرض " + fmt.format(list.length) + " من " + fmt.format(activeOffers().length) + " عروض" : "لا توجد نتائج";
  }

  function statCard(label, value, note) {
    return '<article class="stat-card"><span>' + esc(label) + '</span><strong>' + esc(fmt.format(value)) + (note ? '<small>' + esc(note) + "</small>" : "") + "</strong></article>";
  }
  function ownOffers() {
    return state.profile ? state.offers.filter((offer) => offer.ownerId === state.profile.id || (!offer.ownerId && offer.donor === state.profile.name)) : [];
  }
  function relevantRequests() {
    if (!state.profile) return [];
    return state.offers.flatMap((offer) => (offer.requests || []).filter((request) => state.profile.role === "donor" ? offer.ownerId === state.profile.id || (!offer.ownerId && offer.donor === state.profile.name) : request.charityId === state.profile.id).map((request) => ({ offer, request })));
  }
  function renderDashboard() {
    const profile = state.profile;
    if (!profile) return;
    byId("dashboardTitle").textContent = "مرحبًا، " + profile.name;
    byId("dashboardSubtitle").textContent = profile.role === "donor" ? "تابع عروضك وطلبات الجمعيات لاستلام فائضك." : "استكشف عروض الطعام وتابع حجوزات جمعيتك.";
    byId("addOfferButton").classList.toggle("hidden", profile.role !== "donor");
    const offers = ownOffers();
    const requests = relevantRequests();
    const completed = profile.role === "donor" ? offers.filter((o) => o.status === "completed").length : requests.filter((x) => ["received", "distributed"].includes(x.request.status)).length;
    const active = profile.role === "donor" ? offers.filter(isActive).length : requests.filter((x) => ["pending", "accepted", "handed_over"].includes(x.request.status)).length;
    byId("dashboardStats").innerHTML = [
      statCard(profile.role === "donor" ? "العروض المنشورة" : "طلبات الاستلام", profile.role === "donor" ? offers.length : requests.length),
      statCard("نشطة الآن", active),
      statCard("عمليات مكتملة", completed),
      statCard("المدينة", 0, profile.city)
    ].join("");
    byId("dashboardStats").lastElementChild.querySelector("strong").textContent = profile.city || "—";
    byId("requestsBadge").textContent = fmt.format(requests.filter((x) => x.request.status === "pending").length);
    const content = byId("dashboardContent");
    if (dashboardTab === "requests") {
      content.innerHTML = renderRequests(requests);
    } else if (profile.role === "donor") {
      content.innerHTML = offers.length ? '<div class="dashboard-list">' + offers.map(renderDonorOfferRow).join("") + "</div>" : '<div class="dashboard-empty"><strong>لسه ما نشرت أي عرض</strong>أضف أول عرض فائض وخلي جمعية قريبة تستلمه.</div>';
    } else {
      const charityRequests = requests.slice().sort((a, b) => new Date(b.request.createdAt) - new Date(a.request.createdAt));
      content.innerHTML = charityRequests.length ? '<div class="dashboard-list">' + charityRequests.map((x) => renderCharityRequestRow(x.offer, x.request)).join("") + "</div>" : '<div class="dashboard-empty"><strong>ابدأ من استكشاف العروض</strong>تصفح الطعام المتاح القريب من جمعيتك واحجز ما يناسبكم.</div><button class="button button-primary\" data-view=\"offers\">استكشف العروض ←</button>';
    }
  }

  function renderDonorOfferRow(offer) {
    const meta = cat(offer.category);
    const stateLabel = offer.status === "completed" ? "مكتمل" : new Date(offer.deadline) <= new Date() ? "منتهي" : remainingQty(offer) === 0 ? "محجوز بالكامل" : "متاح";
    const stateClass = offer.status === "completed" ? "complete" : stateLabel === "منتهي" ? "expired" : remainingQty(offer) === 0 ? "reserved" : "";
    const openRequests = (offer.requests || []).filter((r) => r.status === "pending").length;
    const actions = '<button class="mini-button" data-action="details" data-id="' + esc(offer.id) + '">التفاصيل</button>' + (openRequests ? '<button class="mini-button dark" data-action="open-requests" data-id="' + esc(offer.id) + '">طلبات جديدة · ' + fmt.format(openRequests) + "</button>" : "") + (offer.status !== "completed" && offer.status !== "hidden" ? '<button class="mini-button danger" data-action="hide-offer" data-id="' + esc(offer.id) + '">إغلاق العرض</button>' : "");
    return '<article class="dashboard-row"><div class="row-thumb ' + meta.css + '" style="background-color:' + (meta.css === "bakery" ? "#f4ead5" : meta.css === "produce" ? "#e0ebd8" : meta.css === "dessert" ? "#f0e1dc" : "#f2e6d8") + '">' + meta.glyph + '</div><div class="row-main"><strong>' + esc(offer.title) + '</strong><small>' + esc(offer.category) + " · " + esc(niceDate(offer.createdAt)) + '</small><span class="status-pill ' + stateClass + '">' + stateLabel + '</span></div><div class="row-meta"><span><strong>' + fmt.format(remainingQty(offer)) + " / " + fmt.format(offer.quantity) + " " + esc(offer.unit) + '</strong><small>متبقي من الكمية</small></span><span><strong>' + esc(niceDate(offer.deadline)) + '</strong><small>آخر موعد للاستلام</small></span></div><div class="row-actions">' + actions + "</div></article>";
  }

  function renderRequests(items) {
    if (!items.length) return '<div class="dashboard-empty"><strong>ما فيه طلبات حتى الآن</strong>ستظهر هنا طلبات الاستلام ومراحلها.</div>';
    return items.slice().sort((a, b) => new Date(b.request.createdAt) - new Date(a.request.createdAt)).map((item) => {
      const { offer, request } = item;
      if (state.profile.role === "donor") {
        let action = "";
        if (request.status === "pending") action = '<button class="mini-button dark" data-action="accept-request" data-id="' + esc(offer.id) + '" data-request="' + esc(request.id) + '">قبول</button><button class="mini-button danger" data-action="reject-request" data-id="' + esc(offer.id) + '" data-request="' + esc(request.id) + '">رفض</button>';
        else if (request.status === "accepted") action = '<button class="mini-button dark" data-action="handover-request" data-id="' + esc(offer.id) + '" data-request="' + esc(request.id) + '">تأكيد التسليم</button>';
        return '<article class="request-card"><div class="request-info"><span class="request-avatar">♡</span><div><strong>' + esc(request.charityName) + '</strong><small>' + esc(offer.title) + " · " + fmt.format(request.quantity) + " " + esc(offer.unit) + " · وصول " + esc(niceDate(request.eta)) + '</small></div></div><span class="status-pill ' + requestStatusClass(request.status) + '">' + esc(statusText(request.status)) + '</span><div class="request-actions">' + action + "</div></article>";
      }
      let action = "";
      if (request.status === "handed_over") action = '<button class="mini-button dark" data-action="receive-request" data-id="' + esc(offer.id) + '" data-request="' + esc(request.id) + '">تأكيد الاستلام</button>';
      const distribution = request.distributed === true ? " · تم التوزيع" : request.distributed === false ? " · لم يتم التوزيع بعد" : "";
      return '<article class="request-card"><div class="request-info"><span class="request-avatar">' + cat(offer.category).icon + '</span><div><strong>' + esc(offer.title) + '</strong><small>' + esc(offer.donor) + " · " + fmt.format(request.quantity) + " " + esc(offer.unit) + " · وصول متوقع " + esc(niceDate(request.eta)) + esc(distribution) + '</small></div></div><span class="status-pill ' + requestStatusClass(request.status) + '">' + esc(statusText(request.status)) + '</span><div class="request-actions">' + action + "</div></article>";
    }).join("");
  }

  function renderCharityRequestRow(offer, request) {
    const meta = cat(offer.category);
    const distribution = request.distributed === true ? " · تم التوزيع" : request.distributed === false ? " · لم يتم التوزيع بعد" : "";
    return '<article class="dashboard-row"><div class="row-thumb ' + meta.css + '" style="background-color:#eef2e7">' + meta.glyph + '</div><div class="row-main"><strong>' + esc(offer.title) + '</strong><small>' + esc(offer.donor) + " · " + esc(offer.city) + '</small><span class="status-pill ' + requestStatusClass(request.status) + '">' + esc(statusText(request.status)) + '</span></div><div class="row-meta"><span><strong>' + fmt.format(request.quantity) + " " + esc(offer.unit) + '</strong><small>الكمية المطلوبة</small></span><span><strong>' + esc(niceDate(request.eta)) + '</strong><small>موعد الوصول' + esc(distribution) + '</small></span></div><div class="row-actions"><button class="mini-button" data-action="details" data-id="' + esc(offer.id) + '">التفاصيل</button>' + (request.status === "handed_over" ? '<button class="mini-button dark" data-action="receive-request" data-id="' + esc(offer.id) + '" data-request="' + esc(request.id) + '">تأكيد الاستلام</button>' : "") + "</div></article>";
  }

  function renderImpact() {
    const completedRequests = state.offers.flatMap((o) => (o.requests || []).filter((r) => ["received", "distributed"].includes(r.status)));
    byId("impactStats").innerHTML = [
      '<article class="impact-stat"><strong>' + fmt.format(state.history.length + completedRequests.length) + "</strong><span>عملية استلام مكتملة</span></article>",
      '<article class="impact-stat"><strong>' + fmt.format(state.accounts.filter((a) => a.role === "donor").length) + "</strong><span>مطعم أو متجر مسجل</span></article>",
      '<article class="impact-stat"><strong>' + fmt.format(state.accounts.filter((a) => a.role === "charity").length) + "</strong><span>جمعية خيرية مسجلة</span></article>",
      '<article class="impact-stat"><strong>' + fmt.format(activeOffers().length) + "</strong><span>عرض متاح للاستلام</span></article>"
    ].join("");
    const rows = state.history.slice().sort((a, b) => new Date(b.date) - new Date(a.date));
    const dynamic = state.offers.flatMap((offer) => (offer.requests || []).filter((r) => ["received", "distributed"].includes(r.status)).map((r) => ({ id: r.id, title: offer.title, donor: offer.donor, charity: r.charityName, city: offer.city, quantity: r.quantity, unit: offer.unit, date: r.receivedAt || r.createdAt, distributed: r.distributed })));
    const all = rows.concat(dynamic).sort((a, b) => new Date(b.date) - new Date(a.date));
    byId("historyGrid").innerHTML = all.length ? all.map((item) => '<article class="history-card"><div class="history-card-top"><span class="org-dot">✓</span><span class="status-pill complete">مكتمل</span></div><h3>' + esc(item.title) + '</h3><p>' + esc(item.donor) + " ← " + esc(item.charity) + '</p><div class="history-meta"><span>' + esc(item.city) + " · " + esc(niceDate(item.date)) + '</span><strong>' + fmt.format(item.quantity) + " " + esc(item.unit) + "</strong></div></article>").join("") : '<div class="dashboard-empty" style="grid-column:1/-1">ستظهر عمليات التبرع المكتملة هنا.</div>';
  }

  function renderAdmin() {
    byId("adminSummary").innerHTML = [statCard("الحسابات", state.accounts.length), statCard("العروض النشطة", activeOffers().length), statCard("بلاغات مفتوحة", state.reports.filter((report) => report.status !== "resolved").length)].join("");
    const reports = state.reports.filter((report) => report.status !== "resolved");
    byId("adminList").innerHTML = reports.length ? reports.map((report) => {
      const offer = state.offers.find((item) => item.id === report.offerId);
      if (!offer) return "";
      return '<article class="admin-row"><span class="request-avatar">⚑</span><div class="admin-row-main"><strong>' + esc(offer.title) + '</strong><small>بلاغ: ' + esc(report.reason) + " · " + esc(offer.donor) + " · " + esc(offer.city) + '</small></div><div class="admin-row-actions"><button class="mini-button" data-action="details" data-id="' + esc(offer.id) + '">مراجعة العرض</button><button class="mini-button dark" data-action="resolve-report" data-report="' + esc(report.id) + '">إغلاق البلاغ</button><button class="mini-button danger" data-action="hide-offer" data-id="' + esc(offer.id) + '">إخفاء العرض</button></div></article>';
    }).join("") : '<div class="dashboard-empty"><strong>لا توجد بلاغات مفتوحة</strong>كل شيء هادئ في خير حاليًا.</div>';
  }

  function render() {
    renderHome();
    renderOffers();
    if (state.profile) {
      byId("profileButton").classList.remove("hidden");
      byId("joinButton").classList.add("hidden");
      byId("loginButton").classList.add("hidden");
      byId("profileInitial").textContent = state.profile.name.slice(0, 1);
      document.querySelectorAll(".account-nav").forEach((node) => node.classList.remove("hidden"));
      renderDashboard();
    } else {
      byId("profileButton").classList.add("hidden");
      byId("joinButton").classList.remove("hidden");
      byId("loginButton").classList.remove("hidden");
      document.querySelectorAll(".account-nav").forEach((node) => node.classList.add("hidden"));
    }
    renderImpact();
    renderAdmin();
  }

  function modal(content) {
    byId("modalContent").innerHTML = content;
    byId("modalBackdrop").classList.remove("hidden");
    document.body.style.overflow = "hidden";
    byId("modalClose").focus();
  }
  function closeModal() {
    byId("modalBackdrop").classList.add("hidden");
    byId("modalContent").innerHTML = "";
    document.body.style.overflow = "";
    detailOfferId = null;
  }
  function openRoleModal(message, role) {
    selectedRole = role || (state.profile ? state.profile.role : "donor");
    modal('<div class="eyebrow">مجتمع خير</div><h2 id="modalTitle">انضم إلى شبكة خير</h2><p class="modal-lead">' + esc(message || "اختر نوع حسابك وابدأ بمشاركة فائض الطعام أو استلامه.") + '</p><div class="role-picker"><button type="button" class="role-option ' + (selectedRole === "donor" ? "selected" : "") + '" data-role-choice="donor"><span>♧</span><strong>مطعم أو متجر</strong><small>أنشر فائض الطعام وتابع الحجوزات</small></button><button type="button" class="role-option ' + (selectedRole === "charity" ? "selected" : "") + '" data-role-choice="charity"><span>♡</span><strong>جمعية خيرية</strong><small>اكتشف العروض واحجز ما تحتاجه</small></button></div><form id="profileForm"><div class="form-grid"><div class="form-field"><label for="profileName">اسم الجهة</label><input id="profileName" name="name" required maxlength="70" placeholder="' + (selectedRole === "donor" ? "مثال: مطعم الليمون" : "مثال: جمعية بسمة أمل") + '"></div><div class="form-field"><label for="profileCity">المدينة</label><input id="profileCity" name="city" required maxlength="50" placeholder="مثال: الجزائر"></div><div class="form-field"><label for="profilePhone">رقم التواصل</label><input id="profilePhone" name="phone" required maxlength="30" inputmode="tel" placeholder="05XX XXX XXX"></div><div class="form-field"><label for="profileCoverage">' + (selectedRole === "charity" ? "نطاق العمل" : "العنوان") + '</label><input id="profileCoverage" name="coverage" maxlength="100" placeholder="' + (selectedRole === "charity" ? "الأحياء أو البلديات التي تخدمها" : "الحي والشارع") + '"></div></div><button class="button button-primary modal-submit" type="submit">إنشاء حساب تجريبي <span>←</span></button></form><p class="modal-lead" style="margin:13px 0 0;text-align:center">يُحفظ هذا النموذج على جهازك فقط، ولا يرسل البيانات إلى خادم.</p>');
  }

  function openProfileMenu() {
    const profile = state.profile;
    modal('<div class="eyebrow">حسابك في خير</div><h2 id="modalTitle">' + esc(profile.name) + '</h2><p class="modal-lead">' + esc(roleName(profile.role)) + " · " + esc(profile.city || "—") + '</p><div class="detail-meta-grid"><div class="detail-meta"><small>رقم التواصل</small><strong>' + esc(profile.phone || "غير مضاف") + '</strong></div><div class="detail-meta"><small>المدينة</small><strong>' + esc(profile.city || "غير مضافة") + '</strong></div></div><button class="button button-primary modal-submit" data-view="dashboard">فتح لوحة التحكم ←</button><button class="mini-button danger" style="width:100%;margin-top:10px;padding:10px" data-action="logout">تسجيل الخروج</button><p class="modal-lead" style="margin-top:14px">للتجربة فقط: تُحفظ الحسابات محليًا في هذا المتصفح.</p>');
  }

  function openOfferForm() {
    if (!state.profile || state.profile.role !== "donor") {
      openRoleModal("أنشئ حساب مطعم أو متجر حتى تنشر عرضًا.", "donor");
      return;
    }
    const ready = new Date(Date.now() + 20 * 60000);
    const deadline = new Date(Date.now() + 4 * 3600000);
    modal('<div class="eyebrow">شارك الفائض</div><h2 id="modalTitle">أضف عرضًا جديدًا</h2><p class="modal-lead">أدخل وصفًا دقيقًا وموعدًا واضحًا للاستلام.</p><form id="offerForm"><div class="form-grid"><div class="form-field full"><label for="offerTitle">اسم الطعام أو العرض</label><input id="offerTitle" name="title" required maxlength="100" placeholder="مثال: وجبات غداء طازجة"></div><div class="form-field"><label for="offerCategory">نوع الطعام</label><select id="offerCategory" name="category" required><option>وجبات جاهزة</option><option>مخبوزات</option><option>خضار وفواكه</option><option>مواد غذائية</option><option>حلويات</option></select></div><div class="form-field"><label for="offerQuantity">الكمية</label><div style="display:flex;gap:7px"><input id="offerQuantity" name="quantity" required type="number" min="1" max="100000" placeholder="مثال: 20"><select name="unit" aria-label="وحدة القياس"><option>وجبة</option><option>كيس</option><option>صندوق</option><option>سلة</option><option>كغ</option><option>قطعة</option></select></div></div><div class="form-field"><label for="offerReady">جاهز للاستلام</label><input id="offerReady" name="readyAt" required type="datetime-local" value="' + localInputValue(ready) + '"></div><div class="form-field"><label for="offerDeadline">آخر موعد للاستلام</label><input id="offerDeadline" name="deadline" required type="datetime-local" value="' + localInputValue(deadline) + '"></div><div class="form-field"><label for="offerStorage">طريقة الحفظ</label><input id="offerStorage" name="storage" required maxlength="120" placeholder="مثال: يحفظ مبردًا عند 4°م"></div><div class="form-field"><label for="offerAllergens">معلومات الحساسية</label><input id="offerAllergens" name="allergens" maxlength="140" placeholder="مثال: يحتوي على الحليب والقمح"></div><div class="form-field"><label for="offerCity">المدينة</label><input id="offerCity" name="city" required maxlength="50" value="' + esc(state.profile.city || "") + '"></div><div class="form-field"><label for="offerAddress">عنوان الاستلام</label><input id="offerAddress" name="address" required maxlength="140" value="' + esc(state.profile.coverage || "") + '"></div><div class="form-field full"><label for="offerDescription">تفاصيل إضافية</label><textarea id="offerDescription" name="description" maxlength="500" placeholder="أضف وصفًا يساعد الجمعية على معرفة حالة الطعام وطريقة استلامه."></textarea></div></div><button class="button button-primary modal-submit" type="submit">نشر العرض <span>←</span></button></form>');
  }

  function openOfferDetails(id) {
    const offer = state.offers.find((item) => item.id === id);
    if (!offer) return;
    detailOfferId = id;
    const meta = cat(offer.category);
    const available = remainingQty(offer);
    const request = state.profile && state.profile.role === "charity" ? (offer.requests || []).find((item) => item.charityId === state.profile.id && item.status !== "rejected") : null;
    const acceptedForMe = request && ["accepted", "handed_over", "received", "distributed"].includes(request.status);
    const contact = acceptedForMe ? '<div class="detail-meta"><small>بيانات التواصل بعد قبول الحجز</small><strong>' + esc(offer.phone || "تواصل مع الجهة عبر المنصة") + '</strong></div><div class="detail-meta"><small>عنوان الاستلام</small><strong>' + esc(offer.address) + '</strong></div>' : '<div class="detail-notice" style="grid-column:1/-1">تظهر بيانات التواصل وعنوان الاستلام للجمعية بعد قبول طلب الحجز.</div>';
    let actions = "";
    if (state.profile && state.profile.role === "charity" && !request && available > 0 && new Date(offer.deadline) > new Date()) {
      actions = '<form id="requestForm"><div class="form-grid"><div class="form-field"><label for="requestQuantity">الكمية التي تستطيع جمعيتك استلامها (المتاح ' + fmt.format(available) + " " + esc(offer.unit) + ')</label><input id="requestQuantity" name="quantity" type="number" min="1" max="' + available + '" value="' + Math.min(available, 10) + '" required></div><div class="form-field"><label for="requestEta">وقت الوصول المتوقع</label><input id="requestEta" name="eta" type="datetime-local" required value="' + localInputValue(new Date(Math.max(Date.now(), new Date(offer.readyAt).getTime()))) + '"></div></div><button class="button button-primary modal-submit" type="submit">اطلب حجز هذه الكمية <span>←</span></button></form>';
    } else if (request) {
      actions = '<div class="detail-notice">حالة طلب جمعيتك: <strong>' + esc(statusText(request.status)) + '</strong>' + (request.distributed === true ? " · تم تسجيل التوزيع" : "") + '</div>';
    } else if (!state.profile) {
      actions = '<button class="button button-primary modal-submit" data-role="charity">سجل كجمعية لطلب الحجز ←</button>';
    } else if (state.profile.role === "donor") {
      actions = '<div class="detail-notice">سجّل كجمعية خيرية لطلب استلام هذا العرض.</div>';
    } else {
      actions = '<div class="detail-notice">هذا العرض غير متاح للحجز حاليًا.</div>';
    }
    const html = '<div class="detail-hero ' + meta.css + '" style="background:' + (meta.css === "bakery" ? "#f4ead5" : meta.css === "produce" ? "#e0ebd8" : meta.css === "dessert" ? "#f0e1dc" : meta.css === "grocery" ? "#dfeaed" : "#f2e6d8") + '"><span>' + meta.glyph + '</span>' + (available > 0 ? '<span class="offer-badge">متاح · ' + fmt.format(available) + " " + esc(offer.unit) + "</span>" : '<span class="offer-badge urgent">محجوز بالكامل</span>') + '</div><div class="eyebrow">' + esc(offer.category) + " · " + esc(offer.city) + '</div><h2 id="modalTitle">' + esc(offer.title) + '</h2><p class="modal-lead">مقدم من ' + esc(offer.donor) + '</p><div class="detail-meta-grid"><div class="detail-meta"><small>الكمية المعروضة</small><strong>' + fmt.format(offer.quantity) + " " + esc(offer.unit) + '</strong></div><div class="detail-meta"><small>جاهز للاستلام</small><strong>' + esc(niceDate(offer.readyAt)) + '</strong></div><div class="detail-meta"><small>آخر موعد للاستلام</small><strong>' + esc(niceDate(offer.deadline)) + '</strong></div><div class="detail-meta"><small>طريقة الحفظ</small><strong>' + esc(offer.storage || "تواصل مع الجهة") + '</strong></div><div class="detail-meta"><small>معلومات الحساسية</small><strong>' + esc(offer.allergens || "غير مذكورة") + '</strong></div>' + contact + '</div><p class="detail-description">' + esc(offer.description || "لا توجد تفاصيل إضافية.") + '</p>' + actions + '<button class="card-link" data-action="report-offer" data-id="' + esc(offer.id) + '" style="margin-top:12px">⚑ الإبلاغ عن هذا العرض</button>';
    modal(html);
  }

  function openReport(id) {
    const offer = state.offers.find((item) => item.id === id);
    if (!offer) return;
    modal('<div class="eyebrow">مراجعة المجتمع</div><h2 id="modalTitle">الإبلاغ عن عرض</h2><p class="modal-lead">ساعدنا في مراجعة «' + esc(offer.title) + '» باختيار سبب البلاغ.</p><form id="reportForm"><input type="hidden" name="offerId" value="' + esc(id) + '"><div class="form-field"><label for="reportReason">سبب البلاغ</label><select id="reportReason" name="reason"><option>معلومات غير دقيقة</option><option>مشكلة في سلامة الطعام</option><option>الكمية أو الموعد غير صحيح</option><option>محتوى مخالف</option><option>سبب آخر</option></select></div><div class="form-field"><label for="reportNote">تفاصيل إضافية (اختياري)</label><textarea id="reportNote" name="note" maxlength="300"></textarea></div><button class="button button-primary modal-submit" type="submit">إرسال البلاغ</button></form>');
  }

  function openDistributionModal(offerId, requestId) {
    modal('<div class="eyebrow">اكتمل الاستلام</div><h2 id="modalTitle">هل تم توزيع الطعام؟</h2><p class="modal-lead">سجّل ما حدث بعد استلام الطعام حتى تظهر الإحصاءات بشكل أدق.</p><form id="distributionForm"><input type="hidden" name="offerId" value="' + esc(offerId) + '"><input type="hidden" name="requestId" value="' + esc(requestId) + '"><div class="distribution-row"><label for="distributionStatus">حالة التوزيع</label><select id="distributionStatus" name="distributed"><option value="yes">نعم، تم توزيعه على المستفيدين</option><option value="no">ليس بعد، سيتم توزيعه لاحقًا</option></select></div><button class="button button-primary modal-submit" type="submit">حفظ وتأكيد الاستلام <span>✓</span></button></form>');
  }

  function updateRequest(offerId, requestId, status) {
    const offer = state.offers.find((item) => item.id === offerId);
    const request = offer && (offer.requests || []).find((item) => item.id === requestId);
    if (!offer || !request) return;
    if (status === "accepted") {
      if (new Date(offer.deadline).getTime() <= Date.now()) {
        toast("انتهى موعد استلام هذا العرض.", "error");
        return;
      }
      const acceptedElsewhere = (offer.requests || []).filter((item) => item.id !== requestId && ["accepted", "handed_over", "received"].includes(item.status)).reduce((sum, item) => sum + Number(item.quantity || 0), 0);
      if (acceptedElsewhere + Number(request.quantity) > Number(offer.quantity)) {
        toast("الكمية المتاحة لا تكفي لقبول هذا الطلب.", "error");
        return;
      }
    }
    request.status = status;
    if (status === "handed_over") request.handedOverAt = new Date().toISOString();
    if (status === "rejected") request.rejectedAt = new Date().toISOString();
    save();
    render();
    toast(status === "accepted" ? "تم قبول طلب الجمعية." : status === "rejected" ? "تم رفض طلب الاستلام." : "سُجل تسليم الطعام. بانتظار تأكيد الجمعية.");
  }

  function finishReceipt(offerId, requestId, distributed) {
    const offer = state.offers.find((item) => item.id === offerId);
    const request = offer && (offer.requests || []).find((item) => item.id === requestId);
    if (!offer || !request || request.status !== "handed_over") return;
    request.status = "received";
    request.receivedAt = new Date().toISOString();
    request.distributed = distributed;
    const received = (offer.requests || []).filter((item) => ["received", "distributed"].includes(item.status)).reduce((sum, item) => sum + Number(item.quantity || 0), 0);
    if (received >= Number(offer.quantity)) offer.status = "completed";
    save();
    closeModal();
    render();
    toast(distributed ? "تم تأكيد الاستلام وتسجيل التوزيع. شكرًا لصنع الأثر!" : "تم تأكيد الاستلام. يمكنك تسجيل التوزيع لاحقًا.");
  }

  function handleSubmit(event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    const data = new FormData(form);
    if (form.id === "profileForm") {
      event.preventDefault();
      const name = String(data.get("name") || "").trim();
      if (!name) return;
      const account = { id: uid(), name, role: selectedRole, city: String(data.get("city") || "").trim(), phone: String(data.get("phone") || "").trim(), coverage: String(data.get("coverage") || "").trim(), createdAt: new Date().toISOString() };
      state.profile = account;
      state.accounts.push({ name: account.name, role: account.role, city: account.city });
      save();
      closeModal();
      render();
      showView("dashboard");
      toast("أهلًا بك في خير. حسابك جاهز للتجربة.");
    } else if (form.id === "offerForm") {
      event.preventDefault();
      const readyAt = new Date(String(data.get("readyAt")));
      const deadline = new Date(String(data.get("deadline")));
      const quantity = Number(data.get("quantity"));
      if (!Number.isFinite(quantity) || quantity < 1) { toast("أدخل كمية صحيحة.", "error"); return; }
      if (Number.isNaN(readyAt.getTime()) || Number.isNaN(deadline.getTime()) || deadline <= readyAt || deadline <= new Date()) { toast("موعد الاستلام الأخير يجب أن يكون بعد وقت الجاهزية وفي المستقبل.", "error"); return; }
      const offer = { id: uid(), ownerId: state.profile.id, donor: state.profile.name, donorType: "donor", phone: state.profile.phone, city: String(data.get("city") || state.profile.city).trim(), address: String(data.get("address") || "").trim(), title: String(data.get("title") || "").trim(), category: String(data.get("category") || "وجبات جاهزة"), quantity, unit: String(data.get("unit") || "وجبة"), readyAt: readyAt.toISOString(), deadline: deadline.toISOString(), storage: String(data.get("storage") || "").trim(), allergens: String(data.get("allergens") || "").trim(), description: String(data.get("description") || "").trim(), createdAt: new Date().toISOString(), requests: [], status: "active", flagged: false };
      state.offers.unshift(offer);
      save();
      closeModal();
      showView("dashboard");
      dashboardTab = "offers";
      render();
      toast("تم نشر العرض، وأصبح ظاهرًا للجمعيات.");
    } else if (form.id === "requestForm") {
      event.preventDefault();
      const offer = state.offers.find((item) => item.id === detailOfferId);
      if (!offer) return;
      const quantity = Number(data.get("quantity"));
      const eta = new Date(String(data.get("eta")));
      if (!Number.isFinite(quantity) || quantity < 1 || quantity > remainingQty(offer)) { toast("الكمية المطلوبة تتجاوز المتاح.", "error"); return; }
      if (Number.isNaN(eta.getTime()) || eta.getTime() < new Date(offer.readyAt).getTime() || eta.getTime() > new Date(offer.deadline).getTime()) { toast("اختر وقت وصول بين جاهزية الطعام وآخر موعد للاستلام.", "error"); return; }
      offer.requests = offer.requests || [];
      const previous = offer.requests.find((item) => item.charityId === state.profile.id);
      const request = { id: previous ? previous.id : uid(), charityId: state.profile.id, charityName: state.profile.name, quantity, eta: eta.toISOString(), status: "pending", createdAt: new Date().toISOString(), comment: "" };
      if (previous) Object.assign(previous, request); else offer.requests.push(request);
      save();
      closeModal();
      render();
      toast("وصل طلب الحجز إلى الجهة المتبرعة.");
    } else if (form.id === "reportForm") {
      event.preventDefault();
      const report = { id: uid(), offerId: String(data.get("offerId")), reason: String(data.get("reason")), note: String(data.get("note") || ""), status: "open", createdAt: new Date().toISOString() };
      state.reports.push(report);
      const offer = state.offers.find((item) => item.id === report.offerId);
      if (offer) offer.flagged = true;
      save();
      closeModal();
      render();
      toast("شكرًا. وصل البلاغ إلى إدارة المنصة.");
    } else if (form.id === "distributionForm") {
      event.preventDefault();
      finishReceipt(String(data.get("offerId")), String(data.get("requestId")), String(data.get("distributed")) === "yes");
    }
  }

  document.addEventListener("submit", handleSubmit);
  document.addEventListener("click", (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const close = target.closest("#modalClose");
    if (close) { closeModal(); return; }
    if (target.id === "modalBackdrop") { closeModal(); return; }
    const viewButton = target.closest("[data-view]");
    if (viewButton) { event.preventDefault(); closeModal(); showView(viewButton.dataset.view); return; }
    const scrollButton = target.closest("[data-scroll-view]");
    if (scrollButton) { event.preventDefault(); showView(scrollButton.dataset.scrollView); return; }
    const roleButton = target.closest("[data-role]");
    if (roleButton) { openRoleModal("اختر نوع حسابك وابدأ بمشاركة الفائض أو استلامه.", roleButton.dataset.role); return; }
    const roleChoice = target.closest("[data-role-choice]");
    if (roleChoice) { openRoleModal(undefined, roleChoice.dataset.roleChoice); return; }
    const dashTab = target.closest("[data-dash-tab]");
    if (dashTab) {
      dashboardTab = dashTab.dataset.dashTab;
      document.querySelectorAll(".dashboard-tab").forEach((tab) => tab.classList.toggle("active", tab === dashTab));
      renderDashboard();
      return;
    }
    const action = target.closest("[data-action]");
    if (action) {
      const id = action.dataset.id;
      const req = action.dataset.request;
      switch (action.dataset.action) {
        case "details": openOfferDetails(id); break;
        case "open-requests": dashboardTab = "requests"; showView("dashboard"); break;
        case "accept-request": updateRequest(id, req, "accepted"); break;
        case "reject-request": updateRequest(id, req, "rejected"); break;
        case "handover-request": updateRequest(id, req, "handed_over"); break;
        case "receive-request": openDistributionModal(id, req); break;
        case "hide-offer": {
          const offer = state.offers.find((item) => item.id === id);
          if (offer) { offer.status = "hidden"; save(); render(); toast("تم إغلاق العرض."); }
          break;
        }
        case "report-offer": openReport(id); break;
        case "resolve-report": {
          const report = state.reports.find((item) => item.id === action.dataset.report);
          if (report) { report.status = "resolved"; save(); render(); toast("تم إغلاق البلاغ."); }
          break;
        }
        case "logout": state.profile = null; save(); closeModal(); showView("home"); render(); toast("تم تسجيل الخروج من هذا الجهاز."); break;
      }
      return;
    }
    if (target.closest("#joinButton") || target.closest("#loginButton")) { openRoleModal(); return; }
    if (target.closest("#profileButton")) { openProfileMenu(); return; }
    if (target.closest("#addOfferButton")) { openOfferForm(); return; }
    if (target.closest("#mobileMenu")) { byId("mainNav").classList.toggle("open"); return; }
    if (target.closest("#modalClose")) closeModal();
    if (target.closest("#howButton")) byId("howSection").scrollIntoView({ behavior: "smooth", block: "start" });
    if (target.closest("#clearFilters") || target.closest("#emptyReset")) {
      byId("searchInput").value = "";
      byId("cityFilter").value = "";
      byId("categoryFilter").value = "";
      byId("sortFilter").value = "soon";
      renderOffers();
    }
    if (target.closest(".announcement-close")) target.closest(".announcement").remove();
  });

  document.addEventListener("input", (event) => {
    if (event.target && event.target.id === "searchInput") renderOffers();
  });
  document.addEventListener("change", (event) => {
    if (event.target && ["cityFilter", "categoryFilter", "sortFilter"].includes(event.target.id)) renderOffers();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !byId("modalBackdrop").classList.contains("hidden")) closeModal();
  });

  render();
})();
